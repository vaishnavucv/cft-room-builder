#!/bin/bash
n=$((1 + $RANDOM % 7))

if [ $n -eq 1 ]; then
        /usr/bin/echo 'blue:!dr0w$s@p_r3pus' | /usr/sbin/chpasswd

elif [ $n -eq 2 ]; then
        /usr/bin/echo 'blue:sup3r_p@s$w0rd!123' | /usr/sbin/chpasswd

elif [ $n -eq 3 ]; then
        /usr/bin/echo 'blue:sup3r_p@s$w0rd!9' | /usr/sbin/chpasswd

elif [ $n -eq 4 ]; then
        /usr/bin/echo 'blue:thesup3r_p@s$w0rd!' | /usr/sbin/chpasswd

elif [ $n -eq 5 ]; then
        /usr/bin/echo 'blue:sup3r_p@s$w0sup3r_p@s$w0' | /usr/sbin/chpasswd

elif [ $n -eq 6 ]; then
        /usr/bin/echo 'blue:sup3r_p@s$w0!' | /usr/sbin/chpasswd

else
        /usr/bin/echo 'blue:sup3r_p@s$w0rd!23' | /usr/sbin/chpasswd

fi
