#!/bin/bash

elements=("You really think you can take down my machine Blue?" "I really didn't think you would make it this far" "I recommend you leave Blue or I will destroy your shell" "You will never win Blue. I will change your password" "Red Rules, Blue Drools!" "Don't be silly Blue, you will never win" "Get out of my machine Blue!!" "I bet you are going to use linpeas and pspy, noob" "Roses are Red and you suck Blue" "La la la la la la la la la la la la la la la la" "Fine here is the root password WW91IGFyZSBhIGxvc2VyIEJsdWU=" "Here, I'll give you a hint, type exit and you'll be granted a root shell" "There is no way you are going to own this machine" "Roses are Red, but violets aren’t blue, They’re purple, you dope. Now go get a clue." "No you are repeating yourself, you are repeating yourself" "Oh let me guess, you are going to go to the /tmp or /dev/shm directory to run linpeas? Yawn" "Oh let me guess, you are going to go to the /tmp or /dev/shm directory to run Pspy? Yawn" "Fine fine, just run sudo -l and then enter this password WW91IHJlYWxseSBzdWNrIGF0IHRoaXMgQmx1ZQ==")

num_elements=${#elements[@]}

n=$(($RANDOM % num_elements))

for i in $(ps aux | grep black | grep ' pts' | grep -v root | awk '{print $7}')
do
        /usr/bin/echo "${elements[n]}" > /dev/$i
done
