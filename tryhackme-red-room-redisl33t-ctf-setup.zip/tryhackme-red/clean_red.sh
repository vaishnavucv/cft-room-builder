#!/bin/bash

for i in $(ps aux | grep tcp | grep 'redrules' | awk '{print $2}'); do kill -9 $i; done
