#!/bin/bash

/usr/bin/chattr -a /etc/hosts
/usr/bin/cp /root/defense/hosts /etc/hosts
/usr/bin/chmod 646 /etc/hosts
/usr/bin/chattr +a /etc/hosts
